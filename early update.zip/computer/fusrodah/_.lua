
local name = "foo:bar"
local modname = name:gsub(":.*", "")
print(modname)
