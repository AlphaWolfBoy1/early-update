staffranks.register_rank("admin",
                        "Admin",
                        "#ff0f0f")

staffranks.register_rank("modo",
                        "Moderator",
                        "#0d3785")

staffranks.register_rank("guardian",
                        "Guardian",
                        "#3cbebc")

staffranks.register_rank("build",
                        "Builder",
                        "#a50e8e")

staffranks.register_rank("helper",
                        "Helper",
                        "#e2cd11")

staffranks.register_rank("youtuber",
                        "YouTuber",
                        "#7e1f1f")

staffranks.register_rank("miner",
                        "Miner",
                        "#1df16b")

staffranks.register_rank("reporter",
                        "Reporter",
                        "#402283")

staffranks.register_rank("pro-pvp",
                        "PvP_Pro",
                        "#b35300")

staffranks.register_rank("retired",
                        "Experienced",
                        "#7558af")

staffranks.register_rank("host",
                        "Host",
                        "#3d3d3d")
